NOTE:
-----

   - The function 'SL0.m' is a complete and stand-alone implementation of the
Smoothed L0 (SL0) algorithm. It is this function that should be used in your
programs.

   - 'TestSL0.m' is a script to demonstrate the use of SL0. Other M files are
used by this script, not by the function 'SL0.m'.


- Massoud Babaie-Zadeh and Hossein Mohimani
1 July 2008